<?php

// SITE NAME

if ( !defined('SITE_NAME') )
{
    define('SITE_NAME', "Make It Short!");
}

// URL LOCATION (Don't forget "/" at the end !)

if ( !defined('BASE_URL') )
{
    define('BASE_URL', "https://randomnamegeneratorlist.com/sorturl/");
}

// DATABASE CONFIGURATION

if ( !defined('HOST_NAME') )
{
    define('HOST_NAME', "localhost");
}

if ( !defined('DB_NAME') )
{
    define('DB_NAME', "u715870551_sorturl");
}

if ( !defined('USER_NAME') )
{
    define('USER_NAME', "u715870551_sorturl");
}

if ( !defined('USER_PASSWORD') )
{
    define('USER_PASSWORD', "Rohit11@@22");
}
